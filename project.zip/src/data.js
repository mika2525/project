import IMGS1 from "./image/angular.png";
import IMGS2 from "./image/d3.png";
import IMGS3 from "./image/jenkins.png";
import IMGS4 from "./image/postcss.png";
import IMGS5 from "./image/react.png";
import IMGS6 from "./image/redux.png";
import IMGS7 from "./image/sass.png";
import IMGS8 from "./image/ts.png";
import IMGS9 from "./image/webpack.png";

const uniqueCardsArray = [
  {
    type: "code3",
    image: IMGS1,
  },
  {
    type: "code5",
    image: IMGS2,
  },
  {
    type: "code6",
    image: IMGS3,
  },
  {
    type: "code7",
    image: IMGS4,
  },
  {
    type: "code8",
    image: IMGS5,
  },
  {
    type: "code2",
    image: IMGS6,
  },
  {
    type: "code4",
    image: IMGS7,
  },
  {
    type: "code9",
    image: IMGS8,
  },
  {
    type: "code1",
    image: IMGS9,
  },
];

export default uniqueCardsArray;
